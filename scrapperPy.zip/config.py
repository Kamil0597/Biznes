products_category_tab = []
CATEGORY_ID_MAP = {}